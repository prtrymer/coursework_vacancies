package com.example.cinema.config;

public class WebSecurityConfig {
}
