package com.example.cinema.entity;

public class Place {
}
