package com.example.cinema.entity;

import org.springframework.security.core.GrantedAuthority;

public enum Admin implements GrantedAuthority {
    ADMIN;

    @Override
    public String getAuthority() {
        return name();
    }
}