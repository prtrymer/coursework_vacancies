package com.example.cinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CwApplication {

	public static void main(String[] args) {
		SpringApplication.run(CwApplication.class, args);
	}

}
